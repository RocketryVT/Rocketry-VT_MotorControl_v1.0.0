var searchData=
[
  ['write',['write',['../namespacelogging.html#ae42eb935d46020a5f371746468c11169',1,'logging']]]
];
