var searchData=
[
  ['millis',['millis',['../namespacestate.html#a61a125d4614b06b835f9dfe7316d7d04',1,'state::millis(const std::chrono::time_point&lt; C, D &gt; &amp;tp)'],['../namespacestate.html#a7011c99a883347e2e58dd31c6b2e4e05',1,'state::millis(const std::chrono::duration&lt; R, P &gt; &amp;dur)']]]
];
