var searchData=
[
  ['update',['update',['../classtimestamped.html#a200d39bdae8bd4d9cc8b096b7b7b934c',1,'timestamped::update()'],['../classtimestamped.html#aae99f6d6177c840c3f3cfad7a9eab921',1,'timestamped::update(T newdata)']]]
];
