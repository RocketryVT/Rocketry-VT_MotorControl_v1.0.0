var searchData=
[
  ['o2p',['o2p',['../namespacestate.html#af052d5585d6d013aefb7e6cbb7b171d9',1,'state']]],
  ['o2t',['o2t',['../namespacestate.html#a9685a384f776aaea79dace4c45880e37',1,'state']]],
  ['ok',['ok',['../namespacecomms.html#a6853bef43e0ebc79b750ad110dbd0790',1,'comms::ok()'],['../namespacecontrol.html#a54a4d8d2341d5a20ff21c54cdd4d9fc3',1,'control::ok()'],['../namespacehardware.html#ada28b9638cfa957755e3f22e3ca544dd',1,'hardware::ok()'],['../namespacelogging.html#a80c36cc8bac2d594228e275c857fa710',1,'logging::ok()']]],
  ['operator_20t',['operator T',['../classtimestamped.html#a670e2f7bfd93f8a85c3f9c3b9ed75e32',1,'timestamped']]],
  ['operator_28_29',['operator()',['../classtimestamped.html#acf814bfdb0860b6f651f2cb54f423f41',1,'timestamped']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../transmission_8h.html#a4db69046a3078ae1b71be5d1713fda92',1,'operator&lt;&lt;(std::vector&lt; unsigned char &gt; &amp;vec, T data):&#160;transmission.h'],['../transmission_8h.html#af94a95b7784404d07c885255634a6156',1,'operator&lt;&lt;(std::vector&lt; unsigned char &gt; &amp;vec, const std::vector&lt; unsigned char &gt; &amp;data):&#160;transmission.h']]],
  ['operator_3d',['operator=',['../classtimestamped.html#a129c3b74a65a200d849b8701331269fa',1,'timestamped']]],
  ['operator_3e_3e',['operator&gt;&gt;',['../transmission_8h.html#a5e125c535153b810ab46ecdbec991c68',1,'operator&gt;&gt;(std::vector&lt; unsigned char &gt; &amp;vec, T &amp;data):&#160;transmission.h'],['../transmission_8h.html#a9fbbd3b9bb5f31dcf2e9b2b3d89348c3',1,'operator&gt;&gt;(std::vector&lt; unsigned char &gt; &amp;vec, const std::vector&lt; unsigned char &gt; &amp;data):&#160;transmission.h']]]
];
