var searchData=
[
  ['timestamped',['timestamped',['../classtimestamped.html#a055a5d1ff280d37657da9c437e5bbbbc',1,'timestamped::timestamped()'],['../classtimestamped.html#a4e72f31ea8ddf9bd548e5e3b6d9e25a9',1,'timestamped::timestamped(const B &amp;init)']]],
  ['transmit',['transmit',['../namespacecomms.html#aefa13820893aa5e4aaac0caecf10641f',1,'comms::transmit(std::vector&lt; unsigned char &gt; data)'],['../namespacecomms.html#acbbd49b44626996c37e78529614e51bb',1,'comms::transmit(const std::string &amp;str)']]]
];
