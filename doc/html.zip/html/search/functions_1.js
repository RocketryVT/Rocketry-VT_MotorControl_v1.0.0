var searchData=
[
  ['exit',['exit',['../namespacecontrol.html#a7cbd3f8cbfd6da820541cc84db3fedc4',1,'control::exit()'],['../namespacelogging.html#afe163ccc67dd0a89674345b20ee36369',1,'logging::exit()']]]
];
