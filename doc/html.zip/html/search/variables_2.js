var searchData=
[
  ['nh',['nh',['../namespacestate.html#a6fd0371b6e2244e781f774417b0b6e70',1,'state']]],
  ['nitrous_5fperiod',['nitrous_period',['../namespacecfg.html#a0799c9d127dce81cc40bd083593ff5e0',1,'cfg']]]
];
