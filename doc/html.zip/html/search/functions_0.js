var searchData=
[
  ['age',['age',['../classtimestamped.html#a7d07a57737ff4575f3f27e50a00bf1cd',1,'timestamped']]]
];
