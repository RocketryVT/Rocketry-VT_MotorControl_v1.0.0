var searchData=
[
  ['logging',['logging',['../namespacelogging.html',1,'']]]
];
