var searchData=
[
  ['version',['version',['../namespacecfg.html#a387332ba960c1f0758a31aa0f80d5bbc',1,'cfg']]]
];
