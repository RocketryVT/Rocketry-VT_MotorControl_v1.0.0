var searchData=
[
  ['last_5fping',['last_ping',['../namespacestate.html#ae82f0862abf11f4d3536db00d34f595c',1,'state']]],
  ['loop_5fperiod',['loop_period',['../namespacecfg.html#a4e3f5ecec7c91e150d956cd219ae341d',1,'cfg']]]
];
