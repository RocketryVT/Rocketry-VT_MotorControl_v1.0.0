var searchData=
[
  ['behavior',['behavior',['../namespacebehavior.html',1,'']]],
  ['behavior_2eh',['behavior.h',['../behavior_8h.html',1,'']]],
  ['buildpacket',['buildPacket',['../namespacetransmission.html#a0ec668c39ee23777a8226b89c79a1b93',1,'transmission::buildPacket(std::string msg)'],['../namespacetransmission.html#afb3dec4d1697269f80982b13d06f49a8',1,'transmission::buildPacket(uint8_t id, std::vector&lt; uint8_t &gt; data)']]]
];
