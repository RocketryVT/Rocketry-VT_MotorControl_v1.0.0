var searchData=
[
  ['ping_5fperiod',['ping_period',['../namespacecfg.html#a59ea87ca3754d7589e6b40a4d03aa7d2',1,'cfg']]],
  ['pressure_5fperiod',['pressure_period',['../namespacecfg.html#a074de89c71f9a77fdc3613eacee5618f',1,'cfg']]]
];
