var searchData=
[
  ['start_5ftime',['start_time',['../namespacecfg.html#ae03fcaf74db8a442dd6c26a46466b2e4',1,'cfg']]],
  ['status',['status',['../namespacestate.html#a46db97f161380b2c4441f9196e3f8d35',1,'state']]]
];
