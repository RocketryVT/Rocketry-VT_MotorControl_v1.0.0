var searchData=
[
  ['get',['get',['../classtimestamped.html#ad1ad5bb41cf235370495b35e8bd4df44',1,'timestamped']]]
];
