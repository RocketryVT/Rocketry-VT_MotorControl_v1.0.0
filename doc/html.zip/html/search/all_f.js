var searchData=
[
  ['vehicle_5fphase',['vehicle_phase',['../namespacestate.html#ab066b73de180f6e60bfd5152a0dd7d55',1,'state']]],
  ['version',['version',['../namespacecfg.html#a387332ba960c1f0758a31aa0f80d5bbc',1,'cfg']]]
];
